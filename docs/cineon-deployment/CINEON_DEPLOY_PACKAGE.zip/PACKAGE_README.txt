CINEON DEPLOYMENT PACKAGE
Hoàn thiện ngày 22/09/2026. Rà soát mã nguồn ngày 20/09/2026.

1. Đọc CINEON_DEPLOY_A_Z.docx (15 trang).
2. Dùng CINEON_DEPLOY_A_Z.md để sao chép lệnh.
3. Giải nén nội dung gói vào docs/cineon-deployment trong repo movie_web
   để khớp đường dẫn build và scp trong hướng dẫn.
4. Thư mục kit chứa Compose, Caddyfile, Dockerfile và các mẫu env.
5. Điền secret thật trên VPS, không đưa vào repository hoặc image.

Đã xác minh tại máy phát triển:
- Compose parse và các điều kiện cấu hình chính.
- Caddyfile validate thành công.
- 20 khối lệnh Bash cùng smoke.sh đạt kiểm tra cú pháp.
- 3 khối lệnh PowerShell đạt kiểm tra cú pháp.
- 20 trường hợp Caddy HTTP routing với hai upstream giả lập.
- Smoke script đạt khi chạy trên proxy giả lập.
- Bản Word đã render bằng Microsoft Word và xem đủ 15 trang.

Chưa thực hiện trong gói tài liệu:
- Nâng cấp dependency hoặc sửa mã ứng dụng.
- Build image ứng dụng và chạy bộ npm tests của bản phát hành.
- Kết nối VPS, thay DNS, cấp HTTPS thật hoặc kiểm thử tải video.

Thực hiện các mục P0 trong tài liệu trước khi mở production.
Số người xem đáp ứng được cần đo, đặc biệt vì mạng quốc tế 10 Mbps.
