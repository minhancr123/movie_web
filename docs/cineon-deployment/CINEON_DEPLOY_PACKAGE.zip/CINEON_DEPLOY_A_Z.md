# Hướng dẫn triển khai và vận hành Cineon

Domain cineon.me · Ubuntu 24.04 LTS · 1 vCPU · RAM 4 GB · SSD 30 GB

Ngày rà soát 20 tháng 9 năm 2026

## 1 Kết luận và cách dùng tài liệu

Chọn Docker Compose cho ứng dụng, Caddy chạy trên host để cấp HTTPS, MongoDB ở dịch vụ bên ngoài, Redis trong VPS. Build image trên máy cá nhân hoặc CI, không build trên VPS đang phục vụ người xem. Bắt đầu bằng uptime monitor bên ngoài, log có giới hạn dung lượng và Sentry Cloud cho lỗi ứng dụng. Chưa triển khai Sentry tự host hoặc cả bộ Prometheus Grafana Loki trên VPS này.

Điểm giới hạn quan trọng nhất là một lõi CPU và mạng quốc tế 10 Mbps, không phải RAM. Ưu tiên video đi trực tiếp từ nguồn tới trình duyệt. Thông số cổng 10 Gbps không có nghĩa ứng dụng được sử dụng 10 Gbps; nhà cung cấp công bố tốc độ dịch vụ 300 Mbps và quốc tế 10 Mbps. Cần xác nhận giới hạn quốc tế áp dụng riêng từng chiều hay dùng chung và thử đúng nguồn phim thực tế.

Tài liệu dành cho chủ website tự triển khai. Thực hiện lần lượt từ mục 2 đến mục 11, sau đó thiết lập giám sát và backup. Các lệnh gắn nhãn VPS chạy trong Bash qua SSH; các lệnh gắn nhãn máy cá nhân chạy tại repo trên Windows PowerShell. Giá trị VPS_IP, DB_USER, CLUSTER và REGISTRY_USER là chỗ điền thông tin thật, không phải dữ liệu đã xác minh.

Bộ kit đi kèm cung cấp cấu hình triển khai riêng đã tách khỏi cấu hình cũ. Các mục sửa mã nguồn trong phần tối ưu là việc cần hoàn thành trước khi public, không phải thay đổi đã được áp dụng vào ứng dụng. Kiểm tra cú pháp cấu hình không thay thế thử đăng nhập, phát phim hay kiểm thử tải trên VPS.

### Lộ trình thực hiện

| Giai đoạn | Việc chính | Điều kiện đi tiếp |
| --- | --- | --- |
| Chuẩn bị | Chốt nguồn video, tài khoản dịch vụ, bản phát hành | Có đủ thông tin và quyền truy cập |
| Tối ưu | Sửa các mục P0, kiểm thử trên môi trường thử nghiệm | Test và build đạt, không còn tài khoản mặc định yếu |
| Hạ tầng | SSH, Docker, firewall, DNS, MongoDB | Chỉ mở cổng cần thiết, DB kết nối được |
| Triển khai | Pull image, chạy Compose, cấu hình Caddy | Container ổn định và HTTPS hợp lệ |
| Nghiệm thu | Auth, video, socket, tải, backup restore | Checklist đạt trên dữ liệu và thiết bị thực |
| Vận hành | Theo dõi lỗi, dung lượng, cập nhật và rollback | Có cảnh báo và có bản phục hồi đã thử |

## 2 Kiến trúc và ngân sách tài nguyên

Luồng giao diện: trình duyệt → https://cineon.me → Caddy → Next.js ở 127.0.0.1:3000.

Luồng API nghiệp vụ: trình duyệt → https://cineon.me/api → Caddy → Node.js ở 127.0.0.1:5001. Backend, worker và scheduler dùng Redis nội bộ Docker và kết nối MongoDB bên ngoài. NextAuth nằm ở frontend, dù cũng có tiền tố /api/auth; bộ kit định tuyến ngoại lệ cho đúng upstream.

Luồng video ưu tiên: nguồn hoặc CDN → trình duyệt. VPS chỉ tìm nguồn và quản lý phiên. Luồng remux: nguồn → VPS và FFmpeg → người xem; luồng này tiêu tốn cả CPU, dung lượng lẫn mạng. Tắt chuyển mã video không đồng nghĩa tắt xử lý âm thanh hay remux.

Ví dụ tính tải, không phải số đo: 12 người xem video 5 Mbps qua VPS cần khoảng 60 Mbps đầu ra, chưa tính overhead. Nếu nguồn đi qua đường quốc tế 10 Mbps, chỉ hai luồng đầu vào độc lập 5 Mbps đã chạm mức danh nghĩa. Dùng chung một rendition giảm số writer nhưng mỗi người xem vẫn cần băng thông đầu ra. Thêm RAM hoặc bật Cloudflare không tự giải quyết điểm nghẽn này.

| Thành phần | Giới hạn khởi đầu trong kit | Ghi chú |
| --- | --- | --- |
| Backend và FFmpeg con | 1280 MiB | Node heap 512 MiB, một writer remux |
| Frontend | 768 MiB | Node heap 512 MiB, một instance |
| Redis | 512 MiB | Dataset maxmemory 256 MB, còn chỗ cho overhead và persistence |
| Worker | 256 MiB | Không nhân nhiều worker lúc đầu |
| Scheduler | 192 MiB | Chỉ một scheduler |
| Tổng giới hạn container | 3008 MiB | Phần còn lại cho OS, Caddy và page cache |

Đây là mức khởi đầu để đo, không phải bảo đảm ứng dụng vừa bộ nhớ. Theo dõi OOMKilled và đỉnh RSS khi phát phim. Không ép tổng CPU quota của từng container khiến tác vụ nhàn rỗi không nhường được CPU cho tác vụ cần thiết. CPU vẫn chỉ có một lõi dùng chung.

Với SSD 30 GB, đặt ngân sách cache transcode 3 GB và rendition 3 GB, giới hạn log khoảng 30 MB mỗi container và giữ ít nhất 6 GB trống. Image mới và image rollback cũng cần chỗ. Các biến cache là chính sách dọn dữ liệu, không phải disk quota: phiên đang được xem có thể giữ dung lượng vượt ngân sách. Giảm tiếp hoặc chuyển luồng video ra ngoài nếu dung lượng tăng liên tục. Không lưu thư viện phim trên ổ này.

## 3 Danh sách tối ưu trước khi triển khai

### P0 Các mục phải xử lý trước khi mở website công khai

1. Xử lý tài khoản quản trị được tạo sẵn. Hàm createDefaultAdmin trong backend đang tạo mật khẩu cố định khi chưa có tài khoản seed. Bền vững nhất là chuyển thành bước bootstrap một lần với secret nhập riêng. Trong lần triển khai đầu, ít nhất phải đổi mật khẩu seed khi cổng ứng dụng còn chỉ bind localhost, theo mục 9. Không chỉ xóa tài khoản seed vì lần khởi động sau có thể tạo lại.
2. Nâng Node 20 lên Node 24 LTS trong cả Dockerfile và CI. Node 20 hiện đã EOL [1]. Dockerfile mẫu trong kit dùng Node 24; cần chạy lại toàn bộ test trên phiên bản này.
3. Nâng Next.js 14.1.0 lên nhánh được hỗ trợ. Ưu tiên đánh giá nâng lên 16 trên nhánh riêng, đồng bộ React, TypeScript và các thư viện liên quan theo hướng dẫn nâng cấp. Không chỉ sửa số phiên bản rồi đưa lên production. Nhánh 14 hiện ngoài chính sách hỗ trợ [2].
4. Sửa reverse proxy cho NextAuth. Caddyfile cũ chuyển toàn bộ /api/* sang Express, trong khi /api/auth/session, /api/auth/csrf và callback Google thuộc Next.js. Kit định tuyến năm endpoint Express cụ thể trước, rồi chuyển phần /api/auth còn lại sang frontend. Khi thêm endpoint auth nghiệp vụ mới, cập nhật matcher và test định tuyến.
5. Bổ sung NEXTAUTH_URL, NEXTAUTH_SECRET và các biến Google vào đúng container. Domain công khai là https://cineon.me, Google callback là https://cineon.me/api/auth/callback/google. JWT_SECRET của backend và NEXTAUTH_SECRET của frontend phải khác nhau [3].
6. Sửa ví dụ TOKEN_ENCRYPTION_KEYS. Code đọc version dạng số nguyên dương, vì vậy dùng 1:BASE64_KEY, không dùng v1:BASE64_KEY. Giữ nguyên khóa khi deploy hoặc restore; mất khóa sẽ làm token nhà cung cấp đã lưu không giải mã được.
7. Bỏ qua deploy.sh cũ. File có dòng mở đầu trước shebang, còn kiểm tra C# không tương ứng stack hiện tại và chỉ lưu log dưới tên backup. Workflow deploy hiện tại chỉ rollback backend, sử dụng tag latest và reset checkout trên server. Dùng quy trình phát hành ở mục 14 cho đến khi workflow được sửa đầy đủ.
8. Đưa API và frontend về bind 127.0.0.1; Redis không publish cổng. Docker published ports có thể vượt qua luật UFW, nên không dựa riêng vào firewall để giấu các cổng 3000, 5001, 6379 [4][5].
9. Chuyển Redis chứa BullMQ sang noeviction. Repo hiện dùng một Redis cho queue và cache; hai client riêng không có nghĩa hai bộ nhớ riêng. Giữ TTL cache, giữ giới hạn job hoàn tất/thất bại hiện có và cảnh báo bộ nhớ. Khi đầy, noeviction có thể từ chối ghi; nó không tự tạo thêm RAM. Tách Redis cache và queue về sau khi cần [6].
10. Bổ sung .env và .env.* vào cả hai .dockerignore. Frontend hiện thiếu các mẫu này; npm build hoặc COPY có thể đưa cấu hình riêng vào image. Không gửi khóa API server vào NEXT_PUBLIC_*. Hai file Dockerfile mẫu đã giới hạn heap build ở mức hợp lý hơn 192 MB cũ, nhưng build vẫn phải thực hiện ngoài VPS.

### P1 Hiệu năng và chất lượng bản phát hành

Giữ output standalone của Next.js. Cache catalog/TMDB đã tồn tại, nên đo hit rate và số request upstream trước khi viết thêm lớp cache. Dùng ảnh poster đúng kích thước, lazy loading bên dưới màn hình đầu, tránh bật xử lý ảnh nặng hàng loạt trên một lõi. Duy trì phân trang và index MongoDB; kiểm tra query chậm thực tế rồi mới thêm index.

authClient hiện chọn URL công khai ngay cả trong callback phía server. Nên dùng INTERNAL_API_URL khi chạy trên server và URL công khai khi chạy trong trình duyệt, theo cùng cách các API catalog đã làm. Việc này giảm vòng HTTPS ra domain rồi quay về VPS và tránh phụ thuộc hairpin networking. Phải test cả credentials và Google sau thay đổi.

TRUST_PROXY trong clientNetwork.js hiện kiểm tra chuỗi true. Kit đặt true cho logic đó. Đây không tự động cấu hình Express app.set('trust proxy', ...); nếu bổ sung rate limit theo req.ip, chỉ tin số hop hoặc subnet proxy đã xác định. Với Caddy trên host và backend localhost như kit, kiểm thử IP client thật trước khi bật luật giới hạn. Nếu bật thêm Cloudflare, số hop và dải proxy phải được đánh giá lại.

Thêm rate limit cho đăng nhập, đăng ký, tìm kiếm và resolve nguồn; không dùng chung một hạn mức thấp cho các segment HLS. Không cache công khai session, phản hồi cá nhân hóa hoặc URL media có token. Chặn endpoint chẩn đoán nội bộ tại proxy như kit đã làm.

next.config.js đang bỏ qua lỗi TypeScript và ESLint khi build. Bổ sung typecheck riêng vào CI, sửa lỗi và tắt các cờ bỏ qua khi đã tương thích phiên bản Next mới. Một build thành công với ignoreBuildErrors không phải bằng chứng typecheck đạt.

### Cổng kiểm thử trên máy phát triển hoặc CI

Chạy trên Node 24 và có ffmpeg cùng ffprobe trên PATH. Không chạy npm ci trong container production đang phục vụ người xem. Đọc kết quả từng lệnh; nếu lệnh thất bại thì dừng phát hành.

```bash
npm ci --prefix backend-node
npm ci --prefix frontend
ffmpeg -version
ffprobe -version
npm test --prefix backend-node
npm test --prefix frontend
npm run build --prefix frontend
cd frontend
npx tsc --noEmit
cd ..
```

Kiểm tra rằng test media thật sự chạy chứ không bị skip do thiếu FFmpeg. Sau nâng major, cập nhật test/lint script phù hợp trước khi coi CI là cổng chặn. Dùng staging để thử login, Google, chọn nguồn, seek, phụ đề, đổi audio và premiere chat. Bộ cấu hình triển khai không tự sửa các lỗi ứng dụng phát hiện ở bước này.

## 4 Chuẩn bị tài khoản và thông tin

| Mục | Giá trị hoặc việc cần chuẩn bị |
| --- | --- |
| Domain | cineon.me và quyền chỉnh DNS |
| VPS | IPv4 thật, tài khoản SSH, cổng SSH, console cứu hộ |
| OS | Ubuntu 24.04 LTS đã được cài |
| Registry | Tài khoản Docker Hub hoặc registry riêng, quyền push/pull |
| MongoDB | Cluster ngoài VPS, user database, IP allowlist cho VPS |
| Catalog | TMDB read token hoặc API key hợp lệ |
| Nguồn phát | Tài khoản hoặc cấu hình nguồn đang dùng và giới hạn đồng thời |
| Google tùy chọn | OAuth client ID, secret, domain được cấu hình đúng |
| Monitoring | Email nhận cảnh báo, tài khoản Sentry Cloud và uptime monitor |
| Backup | Nơi lưu ngoài VPS, người giữ khóa và lịch thử restore |

Nguồn phim hoặc nhà cung cấp API có thể giới hạn session/IP riêng. Kiểm tra điều kiện tài khoản của bạn, không suy từ số người dùng website ra số luồng upstream được phép dùng. Giữ DB ở region gần VPS và đo độ trễ thực tế; tài liệu này không yêu cầu mua một gói MongoDB cụ thể.

## 5 Chuẩn bị Ubuntu và SSH

Trước tiên dùng console của nhà cung cấp để biết IP và cổng SSH. Giữ một cửa sổ SSH đang đăng nhập trong khi cấu hình. Nếu có control panel hoặc website khác, kiểm tra cổng đang dùng và dịch vụ trước; không ghi đè Caddy/Nginx hay firewall của hệ thống đang phục vụ ứng dụng khác.

Máy cá nhân trong PowerShell:

```powershell
ssh-keygen -t ed25519 -C "cineon-deploy"
ssh root@VPS_IP
```

Nếu nhà cung cấp không dùng root hoặc cổng 22, thay đúng tài khoản và thêm -p SSH_PORT. Lệnh ssh-keygen nên dùng tên file mới nếu bạn đã có key; không ghi đè key hiện có.

VPS với tài khoản có sudo:

```bash
cat /etc/os-release
free -h
df -h /
sudo ss -lntup
sudo apt update
sudo apt upgrade -y
sudo apt install -y ca-certificates curl gnupg git unzip \
  ufw htop sysstat dnsutils openssl
sudo adduser deploy
sudo usermod -aG sudo deploy
sudo install -d -m 700 -o deploy -g deploy /home/deploy/.ssh
sudo nano /home/deploy/.ssh/authorized_keys
sudo chown deploy:deploy /home/deploy/.ssh/authorized_keys
sudo chmod 600 /home/deploy/.ssh/authorized_keys
```

Dán public key từ máy cá nhân, không dán private key. Nếu deploy đã tồn tại thì bỏ qua adduser. Mở cửa sổ khác và thử ssh deploy@VPS_IP cùng sudo -v trước khi đổi chính sách SSH. Sau khi key hoạt động, cấu hình PasswordAuthentication no và PermitRootLogin no trong một file drop-in phù hợp, kiểm tra sudo sshd -t và sudo sshd -T, rồi reload ssh. Kiểm tra thứ tự file cấu hình để chắc giá trị thực sự có hiệu lực.

Chỉ bật UFW sau khi đã cho phép đúng cổng SSH hiện tại. Ví dụ cổng SSH 22:

```bash
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
sudo ufw status verbose
```

Áp dụng tương tự trên firewall của nhà cung cấp. Không mở cổng MongoDB, Redis hay Docker daemon. Dùng lịch cập nhật bảo mật tự động nếu phù hợp và chủ động xếp lịch reboot; cập nhật không thay thế backup. Swap 1 GB chỉ là tùy chọn chống đỉnh bộ nhớ sau khi kiểm tra ổ trống, không phải cách tăng hiệu năng. Nếu swap hoạt động liên tục khi xem phim thì giảm tải hoặc nâng cấu hình.

## 6 Cài Docker Engine và Compose

Kiểm tra docker version và docker compose version trước. Nếu Docker đã được cài từ nguồn khác, đối chiếu tài liệu chính thức trước khi đổi gói; không tự gỡ containerd trên máy có dịch vụ khác. Với máy mới, dùng repository chính thức của Docker [4].

```bash
sudo install -d -m 0755 /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
  -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc
ARCH=$(dpkg --print-architecture)
echo "deb [arch=$ARCH signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu noble stable" \
  | sudo tee /etc/apt/sources.list.d/docker.list >/dev/null
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io \
  docker-buildx-plugin docker-compose-plugin
sudo systemctl enable --now docker
sudo docker run --rm hello-world
sudo usermod -aG docker deploy
```

Đăng xuất rồi đăng nhập lại tài khoản deploy để nhóm docker có hiệu lực. Quyền docker tương đương quyền quản trị host, chỉ cấp cho người vận hành tin cậy. Kiểm tra:

```bash
docker version
docker compose version
sudo install -d -m 750 -o deploy -g deploy /opt/cineon
```

Compose trong hướng dẫn là plugin v2 với cú pháp docker compose, không phải docker-compose cũ. Log rotation nằm trong từng service của kit, nên không cần thay daemon.json toàn máy.

## 7 DNS cho cineon me và MongoDB

Tại nơi đang quản lý DNS, tạo A record tên @ trỏ VPS_IP và CNAME tên www trỏ cineon.me. TTL 300 giây là mức khởi đầu dễ thay đổi. Chỉ tạo AAAA khi IPv6 thực sự hoạt động và firewall cho phép; AAAA sai có thể khiến một phần người dùng gặp lỗi HTTPS.

Nếu dùng Cloudflare, để DNS only trong lần triển khai đầu. Khi hệ thống đã chạy, có thể bật proxy cho phần web sau khi kiểm tra Full strict, real client IP, WebSocket và chính sách cache. Không dùng Flexible. Không coi CDN thông thường là nơi mặc định chuyển tiếp video dung lượng lớn; chọn dịch vụ video/CDN phù hợp nếu cần. Kit hiện giả định Caddy nhận kết nối trực tiếp, chưa cấu hình trusted proxies cho Cloudflare.

```bash
dig +short A cineon.me
dig +short A www.cineon.me
dig +short AAAA cineon.me
```

Kết quả A phải là IP VPS trong chế độ DNS only. Với MongoDB Atlas, tạo database user chỉ đủ quyền cần dùng trên database movieweb và cho phép IPv4 VPS trong Network Access. Code hiện chọn cứng database movieweb; chỉ đổi tên database trong URI không tự đổi database ứng dụng sử dụng. Nếu chuyển dữ liệu từ môi trường cũ, export và restore trước khi chạy production rồi kiểm tra số lượng bản ghi quan trọng.

Đưa URI vào file .env.cineon ở bước sau. URL-encode ký tự đặc biệt trong mật khẩu URI. Không mở allowlist toàn Internet để giải quyết lỗi kết nối. Backup VPS của nhà cung cấp không bao gồm MongoDB nằm ngoài VPS.

## 8 Build và đưa bộ cấu hình lên VPS

### Chuẩn bị image trên máy cá nhân

Trước khi push một nhánh có thể kích hoạt workflow deploy hiện tại, tạm tắt riêng workflow deploy cũ trong GitHub Actions; giữ CI hoạt động. Chỉ bật lại sau khi đã sửa cơ chế release và rollback. Chốt một commit chứa các thay đổi đã kiểm thử. Dùng git diff và git status để chọn file cần commit, không gom secret hay toàn bộ file tạm.

Thêm nội dung dockerignore.additions vào cả hai file .dockerignore đang có. Giữ các rule cũ. Dockerfile đi kèm dùng node:24-alpine và standalone; phải giữ standalone khi nâng Next. Cấu hình build này không sửa package.json hay lockfile thay bạn.

Máy cá nhân PowerShell, đứng tại C:\Users\ADMIN\Downloads\movie_web:

```powershell
$Registry = 'REGISTRY_USER'
$Release = (git rev-parse HEAD).Trim()
git status --short
docker login
docker build --platform linux/amd64 `
  -f docs/cineon-deployment/kit/backend.Dockerfile `
  -t "${Registry}/movie-web:node-${Release}" backend-node
if ($LASTEXITCODE -ne 0) { throw 'Backend build failed' }
docker build --platform linux/amd64 `
  -f docs/cineon-deployment/kit/frontend.Dockerfile `
  -t "${Registry}/movie-web:web-${Release}" frontend
if ($LASTEXITCODE -ne 0) { throw 'Frontend build failed' }
docker push "${Registry}/movie-web:node-${Release}"
if ($LASTEXITCODE -ne 0) { throw 'Backend push failed' }
docker push "${Registry}/movie-web:web-${Release}"
if ($LASTEXITCODE -ne 0) { throw 'Frontend push failed' }
```

Chỉ dùng SHA làm mã release khi working tree dùng để build đã khớp commit đó. Tag là tên có thể bị ghi đè: sau push nên ghi lại digest và dùng repository@sha256:... trong manifest phát hành. Kiểm tra image không chứa .env, private key, cache phát triển hay file phim tạm trước khi push. Nếu registry riêng, dùng pull token trên VPS, không dùng token quyền push.

NEXT_PUBLIC_API_URL, NEXT_PUBLIC_BACKEND_API_URL, NEXT_PUBLIC_SOCKET_URL và NEXT_PUBLIC_SITE_URL đã đặt cho cineon.me trong Dockerfile mẫu. Chúng được đóng vào bundle lúc build; thay biến runtime trên VPS không sửa được bundle đã build sai [7].

### Tải bộ kit

```powershell
scp -r .\docs\cineon-deployment\kit deploy@VPS_IP:/opt/cineon/
```

VPS, đăng nhập bằng deploy:

```bash
cd /opt/cineon
cp kit/compose.cineon.yml .
cp kit/env.cineon.example .env.cineon
cp kit/release.env.example current.env
chmod 600 .env.cineon current.env
nano .env.cineon
nano current.env
```

Điền BACKEND_IMAGE và FRONTEND_IMAGE bằng image vừa push, cùng release. Có thể pin cả REDIS_IMAGE theo digest để lần rollback không vô tình đổi Redis. Không dùng tag latest cho image ứng dụng trong production. Không ghép compose.cineon.yml với docker-compose.prod.yml cũ vì cách merge có thể giữ cổng publish ngoài ý muốn.

Sinh từng secret trên VPS và dán vào file tương ứng:

```bash
openssl rand -hex 32
openssl rand -hex 32
printf '1:'; openssl rand -base64 32
```

Hai chuỗi hex lần lượt dành cho JWT_SECRET và NEXTAUTH_SECRET. Dòng cuối dành cho TOKEN_ENCRYPTION_KEYS. Không chia sẻ output hoặc chụp màn hình secret. Trong file Compose env, dùng nháy đơn khi giá trị có dấu dollar literal. Không source .env.cineon vào Bash; đây là định dạng env cho Compose, không phải script.

Nếu dùng Google: tạo OAuth web client, thêm origin https://cineon.me và callback https://cineon.me/api/auth/callback/google. Điền ID và secret; ID được đưa tới backend và frontend, secret chỉ tới frontend server. Kiểm tra trạng thái consent screen và danh sách test user nếu ứng dụng OAuth chưa public. Nếu chưa dùng Google, nên ẩn hoặc tắt provider/nút Google trong ứng dụng và kiểm tra login credentials riêng.

## 9 Chạy ứng dụng trong mạng nội bộ trước

Tạo hàm dc trong mỗi phiên SSH mới để mọi lệnh dùng đúng file env, project và Compose. Cách này tránh thao tác nhầm stack khác trên cùng VPS.

```bash
cd /opt/cineon
dc() {
  docker compose -p cineon \
    --env-file /opt/cineon/.env.cineon \
    --env-file /opt/cineon/current.env \
    -f /opt/cineon/compose.cineon.yml "$@"
}
dc config --quiet
docker login
dc pull
dc up -d --wait --wait-timeout 180
dc ps
curl -fsS http://127.0.0.1:5001/health
curl -fsS http://127.0.0.1:3000/api/auth/providers
dc exec -T redis redis-cli ping
dc exec -T backend-node ffmpeg -version
```

Không chia sẻ output dc config đầy đủ vì nó có thể chứa secret. --quiet chỉ xác thực cấu hình. Worker và scheduler không có HTTP server riêng; kit tắt HEALTHCHECK API kế thừa cho hai process này. Trạng thái running của chúng không chứng minh queue đang xử lý thành công, nên vẫn cần kiểm tra job nghiệp vụ và tuổi job.

Kiểm tra MongoDB thật, thay vì chỉ nhìn endpoint /health:

```bash
dc exec -T backend-node node --input-type=module -e '
import { MongoClient } from "mongodb";
const c = new MongoClient(process.env.MONGODB_URI);
try {
  await c.connect();
  console.log(await c.db("movieweb").command({ ping: 1 }));
} finally { await c.close(); }
'
```

/health hiện chỉ trả liveness của process; nó không ping MongoDB hay Redis ở mỗi request. Kết quả mong đợi của lệnh MongoDB là đối tượng có ok: 1. Redis trả PONG. Đây là tiêu chí cần kiểm tra trên VPS, không phải kết quả đã chạy trong tài liệu.

### Đổi mật khẩu tài khoản seed trước khi mở Caddy

Nếu code đã được sửa để bootstrap an toàn, dùng quy trình mới đã được kiểm thử. Với code seed hiện tại, cập nhật mật khẩu cho bản ghi admin@movieweb.com trong database movieweb trước khi public. Lệnh sau giữ nguyên email seed để startup không tạo lại tài khoản mật khẩu cũ. Nhập mật khẩu mạnh dài ít nhất 16 ký tự, lưu trong password manager.

```bash
read -rsp 'New admin password: ' ADMIN_PASSWORD; echo
export ADMIN_PASSWORD
dc exec -T -e ADMIN_PASSWORD backend-node \
  node --input-type=module -e '
import { MongoClient } from "mongodb";
import bcrypt from "bcryptjs";
const p = process.env.ADMIN_PASSWORD || "";
if (p.length < 16) throw new Error("Password too short");
const c = new MongoClient(process.env.MONGODB_URI);
try {
  await c.connect();
  const r = await c.db("movieweb").collection("users").updateOne(
    { email: "admin@movieweb.com", role: "admin" },
    { $set: { password: await bcrypt.hash(p, 12),
              updatedAt: new Date() } }
  );
  if (r.matchedCount !== 1) throw new Error("Expected one admin");
  console.log("ADMIN_PASSWORD_UPDATED");
} finally { await c.close(); }
'
unset ADMIN_PASSWORD
```

Chỉ tiếp tục nếu lệnh thành công. Nếu lệnh lỗi, vẫn unset ADMIN_PASSWORD trong shell rồi kiểm tra nguyên nhân. Không dùng lệnh này để khôi phục một database khác hoặc đổi mật khẩu account không thuộc website của bạn. Sau public phải kiểm tra mật khẩu cũ thất bại và mật khẩu mới đăng nhập được; về lâu dài loại bỏ seed mật khẩu cố định khỏi code.

## 10 Cài Caddy và bật HTTPS

Chọn Caddy làm reverse proxy duy nhất cho site. Kiểm tra cổng 80 và 443 trước khi cài. Caddy tự cấp và gia hạn chứng chỉ khi DNS cùng đường vào hợp lệ [8][9]. Cài theo repository stable chính thức, hoặc làm theo hướng dẫn chính thức nếu Caddy đã có sẵn.

```bash
sudo apt install -y debian-keyring debian-archive-keyring \
  apt-transport-https curl gnupg
curl -fsSL https://dl.cloudsmith.io/public/caddy/stable/gpg.key \
  | sudo gpg --dearmor \
    -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl -fsSL https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt \
  | sudo tee /etc/apt/sources.list.d/caddy-stable.list >/dev/null
sudo chmod a+r /usr/share/keyrings/caddy-stable-archive-keyring.gpg
sudo chmod a+r /etc/apt/sources.list.d/caddy-stable.list
sudo apt update
sudo apt install -y caddy
```

Với lần cài mới, tiếp tục sau khi mục 9 đã đạt:

```bash
sudo cp /etc/caddy/Caddyfile /etc/caddy/Caddyfile.pre-cineon
sudo cp /opt/cineon/kit/Caddyfile /etc/caddy/Caddyfile
sudo caddy validate --config /etc/caddy/Caddyfile
sudo systemctl reload caddy
sudo systemctl status caddy --no-pager
curl -I https://cineon.me
curl -I https://www.cineon.me
```

Không reload khi validate lỗi. Nếu Caddy đang phục vụ site khác, thêm site block thay vì thay toàn bộ file. Kit có www redirect nên phải cấu hình DNS www; nếu không sử dụng www, bỏ block đó. /api được giữ nguyên khi proxy tới Express, không dùng handle_path làm mất tiền tố. WebSocket /socket.io cũng tới backend.

Chưa bật HSTS preload trong lần đầu. Sau khi HTTPS và redirect ổn định mới cân nhắc HSTS theo nhu cầu domain. Không bật cache mọi URL trên Cloudflare: session, API riêng tư và URL có token phải được loại trừ.

## 11 Nghiệm thu trước khi mời người dùng

VPS hoặc máy kiểm tra có Bash:

```bash
bash /opt/cineon/kit/smoke.sh https://cineon.me
docker stats --no-stream
free -h
df -h /
dc logs --tail 100 backend-node frontend
```

| Kiểm tra | Kết quả cần đạt |
| --- | --- |
| Trang chủ và HTTPS | Mở được trên máy khác, không mixed content |
| NextAuth | providers, session, csrf trả JSON đúng, không rơi vào Express 404 |
| API riêng tư | /api/auth/me chưa đăng nhập trả 401 |
| Credentials | Đăng ký, login, logout, tải lại trang vẫn đúng session |
| Google nếu bật | Callback trả về cineon.me và backend xác thực token |
| Admin | Mật khẩu seed cũ thất bại, tài khoản mới/đã đổi pass hoạt động |
| Video | Có hình và tiếng, đúng phụ đề, tua tiến/lùi, đổi audio |
| Nguồn | Xác định request video đi tới nguồn hay VPS bằng Network tab |
| Socket | Chat premiere hoạt động giữa hai trình duyệt |
| Database và queue | Favorite, lịch sử và job ghi dữ liệu thành công |
| Cổng mạng | Máy bên ngoài không truy cập trực tiếp 3000, 5001, 6379 |
| Dữ liệu sau restart | Restart có kế hoạch không làm mất user hoặc secret |

Chạy thử tải tăng dần 5, 10 rồi 15 người xem trong ít nhất 20 đến 30 phút mỗi mức. Tách kịch bản xem cùng phim, khác phim, cache lạnh và tua đồng thời. Test HTML bằng công cụ HTTP không thay thế tải video. Ghi lại bitrate, startup time, số lần rebuffer, CPU, RAM, tốc độ quốc tế, disk growth và ffmpeg writer count.

Ngưỡng tham khảo ban đầu: API p95 dưới 1 giây với dữ liệu đã cache, tỷ lệ 5xx dưới 1%, không OOM/restart ngoài dự kiến và còn trên 20% ổ trống. Đây là mục tiêu vận hành tự đặt, không phải SLA hay công suất đã đo. Nếu CPU hoặc mạng quốc tế gần đầy liên tục thì giảm remux, giảm bitrate được chọn hoặc nâng hạ tầng phù hợp. Tăng REMUX_MAX_WRITERS từ 1 lên 2 chỉ sau khi có số đo đủ dư tài nguyên.

## 12 Sentry Grafana và bộ DevOps nên dùng

### Quyết định cho giai đoạn đầu

| Công cụ | Đề xuất | Lý do và giới hạn |
| --- | --- | --- |
| Docker Compose | Dùng ngay | Một VPS, ít service, dễ tái tạo |
| Caddy | Dùng ngay | HTTPS và reverse proxy trong một service |
| GitHub Actions | Dùng CI ngay | Test và build ngoài VPS, manual promote lúc đầu |
| Uptime monitor bên ngoài | Dùng ngay | Phát hiện cả trường hợp VPS mất mạng hoặc tắt |
| Sentry Cloud | Nên thêm sớm | Theo dõi lỗi Next.js và Express có release/version |
| Grafana Cloud và Alloy | Tùy chọn sau | Hữu ích khi cần lịch sử CPU, RAM, disk và alert |
| Grafana Prometheus Loki tự host | Chưa cần | Chia sẻ một lõi và SSD với ứng dụng, tăng công vận hành |
| Sentry tự host | Không chọn cho VPS này | Yêu cầu tài nguyên vượt cấu hình này [10] |
| Kubernetes Jenkins control panel | Chưa cần | Tăng số thành phần mà chưa giải quyết nút thắt hiện tại |

Sentry và Grafana không thay nhau: Sentry trả lời lỗi code nào đang xảy ra; metrics trả lời CPU, RAM, ổ đĩa hoặc mạng có quá tải không. Uptime monitor bên ngoài trả lời người dùng còn truy cập được website không. Backup trả lời có phục hồi được dữ liệu không.

### Tích hợp Sentry theo từng bước

Tạo hai project production tách biệt cho Next.js và Node/Express, hoặc ít nhất phân biệt service bằng tag. Tích hợp SDK chính thức trên nhánh riêng, kiểm tra tương thích sau nâng Next. Repo backend dùng ESM nên việc khởi tạo instrumentation phải xảy ra trước khi import Express và các thư viện cần instrument [11][12].

Ban đầu chỉ thu lỗi: tắt tracing, profiling và Session Replay. Đặt environment production, release bằng cùng SHA hoặc release ID của image, sendDefaultPii false. Thiết lập beforeSend và bộ lọc phía dịch vụ để xóa Authorization, Cookie, JWT, API key, body đăng nhập, URL nguồn có query token và thông tin cá nhân không cần thiết. sendDefaultPii false không thay thế việc lọc thủ công các dữ liệu bạn tự đính kèm.

DSN trình duyệt không phải secret xác thực, nhưng SENTRY_AUTH_TOKEN dùng upload source map là secret CI: không đưa vào NEXT_PUBLIC_* hay image runtime. Thiết lập quota và cảnh báo chi phí theo plan đang dùng, không mặc định gói miễn phí đủ mãi. Kiểm tra source map và gửi một lỗi thử trong staging; lỗi phải hiện đúng project, release và stack trace mà không lộ token. Không bật endpoint cố tình gây lỗi ở production.

Sentry chỉ hoạt động sau khi cài SDK và nối error handler; thêm biến SENTRY_DSN vào Compose mà chưa sửa code sẽ không tự thu lỗi. Bộ kit hiện chưa cài SDK để tránh làm người triển khai nhầm rằng giám sát đã hoạt động.

### Khi nào thêm Grafana

Trong tuần đầu có thể dùng uptime monitor, docker stats, htop, df và log giới hạn. Nếu cần xem xu hướng hoặc cảnh báo tài nguyên tự động, chọn Grafana Cloud Linux integration với Alloy thay vì tự host toàn stack. Chỉ thu metrics cần thiết, chu kỳ 30 đến 60 giây, giới hạn nhãn và kiểm tra RSS của agent trên máy thật. Alloy vẫn tiêu tốn tài nguyên và kết nối outbound, không phải miễn phí về CPU/RAM [13].

Chưa gửi toàn bộ log HLS lên cloud. Đặc biệt loại URL có token khỏi log/breadcrumb. Một dashboard khởi đầu chỉ cần CPU utilization và steal, MemAvailable, swap, disk free/inode, disk I/O, network RX/TX, container restart/OOM, API error rate và queue age. Muốn đo p95 API hoặc tuổi job cần instrument/export thêm; /health hiện tại không cung cấp các metric đó.

### Cảnh báo có thể hành động

| Tín hiệu | Mức khởi đầu | Hành động |
| --- | --- | --- |
| Uptime | Hai lần kiểm tra lỗi liên tiếp | Kiểm tra DNS, Caddy, container và nhà cung cấp |
| CPU | Trên 85% trong 10 phút | Xem writer, process và CPU steal |
| RAM | MemAvailable dưới 15% trong 5 phút | Xem RSS, OOM, giới hạn heap và container |
| Disk | Còn dưới 20%; khẩn khi dưới 10% | Xác định cache, image, log; dọn có chọn lọc |
| API | 5xx trên 1% trong 5 phút, đủ số request | Đối chiếu release mới và Sentry |
| Queue | Job chờ lâu hơn 5 phút | Kiểm tra worker, Redis và lỗi retry |
| Chứng chỉ | Còn dưới 14 ngày | Kiểm tra log gia hạn và đường vào 80/443 |

Không đặt hàng chục cảnh báo ngay từ đầu. Gửi một cảnh báo thử đến kênh thật, gộp lỗi lặp, ghi rõ người nhận và cách xử lý. Monitor trên chính VPS không đủ để báo khi VPS đã tắt.

## 13 Backup và thử phục hồi

Backup tuần của nhà cung cấp là một lớp bổ sung, không phải toàn bộ kế hoạch. Với lịch tuần, lượng dữ liệu mất có thể tới khoảng một tuần; consistency, retention và cách restore cần hỏi nhà cung cấp. Snapshot VPS không chứa MongoDB Atlas ở bên ngoài.

Mục tiêu khởi đầu đề xuất: RPO dữ liệu không quá 24 giờ, RTO 1 đến 2 giờ. Đây là mục tiêu cần kiểm chứng bằng buổi diễn tập, chưa phải cam kết đạt được. Dùng backup managed của MongoDB nếu plan hỗ trợ, hoặc mongodump từ máy backup tin cậy với URI lấy từ kho secret. Không mặc định Atlas free có snapshot/PITR. Với ghi liên tục, lựa chọn phương pháp backup nhất quán phù hợp trước khi tự làm dump.

| Dữ liệu | Cách bảo vệ |
| --- | --- |
| MongoDB | Backup ngoài VPS hằng ngày; thử restore sang môi trường riêng |
| .env.cineon và khóa mã hóa | Bản sao mã hóa ngoài VPS hoặc secret manager |
| current.env và previous.env | Lưu cùng digest image và release đã kiểm thử |
| Compose và Caddyfile | Version control không có secret; backup bản đang chạy |
| Redis queue | AOF volume; backup nhất quán nếu cần giữ job đang chờ |
| Cache video | Có thể tái tạo; không ưu tiên backup dung lượng lớn |

Ví dụ lưu bộ cấu hình, chưa bao gồm MongoDB hoặc Redis:

```bash
cd /opt/cineon
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
install -d -m 700 backups
umask 077
tar -czf "backups/config-$STAMP.tgz" \
  .env.cineon current.env compose.cineon.yml
sudo cp /etc/caddy/Caddyfile "backups/Caddyfile-$STAMP"
sudo chown deploy:deploy "backups/Caddyfile-$STAMP"
chmod 600 "backups/Caddyfile-$STAMP"
```

Archive chứa secret ở dạng rõ: chỉ là bước gom file trên host, chưa phải backup ngoài máy. Dùng công cụ backup mã hóa như restic tới kho riêng hoặc secret manager phù hợp, giới hạn quyền đọc và giữ khóa giải mã ở nơi độc lập. Đừng để backup hằng ngày tích lũy vô hạn trên ổ 30 GB. Hẹn lịch backup và cảnh báo nếu lần chạy cuối quá 24 giờ; kiểm tra log thành công và dung lượng object ở nơi nhận.

Mỗi tháng thử trên VPS hoặc môi trường riêng: cài lại hạ tầng, lấy lại Compose và image theo digest, khôi phục MongoDB, khôi phục đúng TOKEN_ENCRYPTION_KEYS và secret, chạy stack rồi xác minh user, lịch sử, favorite và kết nối provider. Không restore đè production để thử. Ghi thời gian thực tế, số bản ghi kiểm tra và các bước còn thiếu. Giữ ít nhất một bản ngoài tài khoản VPS nếu có thể.

## 14 Cập nhật và rollback một bản phát hành

### CI nên làm gì

Pipeline khuyến nghị: pull request → npm ci → backend/frontend tests với FFmpeg thật → typecheck và production build → build hai image → scan dependency/image → push tag release và lưu digest → duyệt production → pull và kiểm tra → smoke → theo dõi lỗi sau phát hành. Pin các action theo commit đã kiểm tra, giới hạn quyền workflow và không để token registry/SSH xuất hiện trong log.

Giai đoạn đầu chỉ tự động test/build, còn triển khai thủ công theo mục này. Thêm concurrency để tránh hai release cùng deploy. Không chạy npm test lần hai chỉ để dò skip mà làm mất exit code qua pipe; lưu log của một lần chạy và giữ pipefail khi triển khai kiểm tra này. SSH automation phải xác minh host key. Chưa dùng Watchtower để tự cập nhật image ứng dụng không qua kiểm thử.

### Quy trình thay image khi cấu hình và schema giữ nguyên

Hoàn thành backup, kiểm tra ít nhất 6 GB trống và bảo đảm image bản cũ vẫn còn trong registry. Chọn khung giờ ít người xem vì một VPS một replica không có zero downtime; các phiên đang remux có thể bị ngắt khi backend restart.

```bash
cd /opt/cineon
cp current.env previous.env
cp compose.cineon.yml compose.previous.yml
cp .env.cineon .env.previous
chmod 600 previous.env .env.previous
sudo cp /etc/caddy/Caddyfile /etc/caddy/Caddyfile.previous
cp kit/release.env.example next.env
nano next.env
```

Điền cả BACKEND_IMAGE và FRONTEND_IMAGE của cùng release mới. Xác thực và pull trước khi thay current.env để lỗi tải image không ảnh hưởng dịch vụ cũ:

```bash
docker compose -p cineon --env-file .env.cineon \
  --env-file next.env -f compose.cineon.yml config --quiet
docker compose -p cineon --env-file .env.cineon \
  --env-file next.env -f compose.cineon.yml pull
```

Chỉ tiếp tục khi cả hai lệnh thành công. Sau đó:

```bash
cp next.env current.env
dc up -d --wait --wait-timeout 180
bash kit/smoke.sh https://cineon.me
dc ps
```

Nếu up hoặc smoke thất bại, thực hiện rollback ngay thay vì tiếp tục coi release thành công. Kiểm tra thêm một lần login và playback thật, vì smoke chỉ kiểm tra HTTP. Trong 15 đến 30 phút đầu, theo dõi Sentry, restart count, queue và disk growth.

### Rollback đồng bộ toàn bộ ứng dụng

```bash
cd /opt/cineon
cp previous.env current.env
cp compose.previous.yml compose.cineon.yml
dc up -d --wait --wait-timeout 180
bash kit/smoke.sh https://cineon.me
dc ps
```

Compose dùng cùng BACKEND_IMAGE cho API, worker và scheduler; frontend có image riêng. Cách này đưa cả bốn process về bản đã lưu, không chỉ backend. Giữ project name cineon và tên volume ổn định. Không dùng down -v, volume prune hay system prune --volumes để cập nhật ứng dụng.

Nếu đã sửa Caddy, validate và khôi phục Caddyfile.previous rồi reload. Nếu đã thay env, chỉ phục hồi .env.previous sau khi rà soát thay đổi secret: không đưa lại khóa đã bị thu hồi hoặc mất an toàn. Khi xoay TOKEN_ENCRYPTION_KEYS, giữ khóa cũ cần để đọc dữ liệu đã mã hóa và thêm khóa mới theo version số. Rollback image không rollback database; migration phá vỡ tương thích phải có kế hoạch riêng và backup đã thử. Chưa tự động hóa migration không đảo ngược trong pipeline này.

## 15 Xử lý sự cố và lịch vận hành

| Triệu chứng | Kiểm tra trước | Hướng xử lý |
| --- | --- | --- |
| Domain chưa mở | DNS A/AAAA, firewall nhà cung cấp và UFW | Sửa record sai hoặc mở đúng 80/443 |
| HTTPS chưa có chứng chỉ | journalctl của Caddy, DNS www | Kiểm tra domain về đúng host và đường vào ACME |
| 502 | dc ps, health, bind localhost | Sửa ứng dụng chưa lên hoặc sai upstream |
| Login vòng lặp hoặc session 404 | NextAuth route, secret, callback domain | Giữ NextAuth trên frontend, API login trên backend |
| Catalog trắng | TMDB key, outbound, DNS và Redis | Kiểm tra API upstream và timeout, tránh retry storm |
| Phim xoay liên tục | Network tab, codec, writer, mạng quốc tế | Ưu tiên direct, xem lỗi nguồn và tốc độ nhận dữ liệu |
| Container restart | OOMKilled, logs và docker stats | Giảm tải hoặc sửa memory leak, không chỉ tăng restart |
| Disk tăng nhanh | docker system df, log, transcode volume | Dọn đúng cache không còn dùng và image đã hết nhu cầu |
| Job tồn đọng | Redis ping, memory, worker logs | Sửa Redis/worker trước khi cho thêm tải |

Lệnh chẩn đoán trên VPS:

```bash
sudo journalctl -u caddy -n 100 --no-pager
dc logs --tail 100 backend-node frontend backend-node-worker
docker stats --no-stream
docker system df
df -h /
df -i /
vmstat 1 5
dc exec -T redis redis-cli INFO memory
dc exec -T redis redis-cli CONFIG GET maxmemory-policy
docker inspect --format '{{.State.OOMKilled}} {{.RestartCount}}' \
  "$(dc ps -q backend-node)"
```

Không đăng log thô chứa secret hoặc link nguồn có token lên nơi công khai. Không xóa volume Redis/MongoDB để xử lý đầy ổ. Không tăng mọi timeout trước khi tìm nguyên nhân. Cache dọn theo active session; việc xóa file đang phát có thể làm người xem mất luồng.

Hằng ngày xem cảnh báo, lỗi mới, backup gần nhất và disk. Hằng tuần xem sử dụng quốc tế, chi phí dịch vụ, dependency updates và các image rollback còn cần. Hằng tháng diễn tập restore, rà SSH key/secret và xem lại giới hạn tài nguyên theo số đo. Trước mỗi release phải có một người chịu trách nhiệm theo dõi và quyết định rollback.

## 16 Checklist bàn giao

- [ ] Ubuntu 24.04 đã cập nhật và SSH key hoạt động.
- [ ] 80/443 và đúng cổng SSH được mở; cổng ứng dụng chỉ ở localhost.
- [ ] DNS cineon.me và www trỏ đúng; không còn AAAA sai.
- [ ] Các mục P0 đã xử lý; admin seed không dùng mật khẩu cố định.
- [ ] Node/Next ở nhánh hỗ trợ; test, typecheck và build đạt trên release này.
- [ ] Image đúng commit và digest được lưu; .env không nằm trong image.
- [ ] NextAuth và Express auth tới đúng upstream; secret được tách riêng.
- [ ] MongoDB/Redis được kiểm tra độc lập; worker xử lý job thật.
- [ ] HTTPS hợp lệ, credentials/Google và Socket.IO đã kiểm tra.
- [ ] Video đã thử direct, remux, seek, audio, phụ đề và tải đồng thời.
- [ ] Mạng quốc tế và dung lượng ổ có đủ khoảng trống theo số đo.
- [ ] Uptime alert được thử từ bên ngoài; Sentry đã gửi và nhận lỗi thử nếu bật.
- [ ] Backup ngoài VPS tồn tại và restore đã diễn tập.
- [ ] previous.env cùng image cũ sẵn có; quy trình rollback đã được thử.

## 17 Đối chiếu mã nguồn và tài liệu chính thức

Các vị trí sau được rà soát ở working tree ngày 20 tháng 9 năm 2026. Số dòng có thể thay đổi khi bạn tiếp tục sửa code. Root repo là C:\Users\ADMIN\Downloads\movie_web.

| Thành phần trong repo | Phát hiện dùng trong hướng dẫn |
| --- | --- |
| docker-compose.prod.yml dòng 12 và 53 đến 60 | Redis allkeys-lru, cache 60 GB, giới hạn writer |
| deploy.sh và .github/workflows/deploy.yml | Script cũ, tag latest, rollback chưa đồng bộ |
| frontend/Dockerfile và backend-node/Dockerfile | Node 20; heap build frontend 192 MB |
| frontend/package.json và frontend/next.config.js | Next 14.1.0, standalone, bỏ qua type/lint khi build |
| frontend/src/app/api/auth/[...nextauth]/route.ts | NextAuth credentials và Google, NEXTAUTH_SECRET |
| backend-node/routes/auth.js | Năm endpoint auth nghiệp vụ ở Express |
| backend-node/controllers/authController.js hàm createDefaultAdmin | Tự tạo admin seed với mật khẩu cố định |
| backend-node/services/security/tokenVault.js hàm parseKeys | Version khóa phải là số nguyên dương |
| backend-node/services/playback/clientNetwork.js | TRUST_PROXY được đọc theo chuỗi true |
| backend-node/config/database.js | Database movieweb được chọn trong code |
| backend-node/config/queue.js và redis.js | Chung REDIS_URL, đã có TTL và giới hạn số job lưu |
| backend-node/server.js endpoint /health | Liveness, chưa phải readiness phụ thuộc DB/Redis |

Nguồn tham khảo chính thức được kiểm tra khi soạn tài liệu:

1. Node.js Releases — https://nodejs.org/en/about/previous-releases
2. Next.js Support Policy — https://nextjs.org/support-policy
3. NextAuth Options — https://next-auth.js.org/configuration/options
4. Docker Engine on Ubuntu — https://docs.docker.com/engine/install/ubuntu/
5. Docker Port Publishing — https://docs.docker.com/engine/network/port-publishing/
6. BullMQ Going to Production — https://docs.bullmq.io/guide/going-to-production
7. Next.js Self Hosting — https://nextjs.org/docs/app/guides/self-hosting
8. Caddy Install — https://caddyserver.com/docs/install
9. Caddy Automatic HTTPS — https://caddyserver.com/docs/automatic-https
10. Sentry Self Hosted — https://develop.sentry.dev/self-hosted/
11. Sentry Next.js — https://docs.sentry.io/platforms/javascript/guides/nextjs/
12. Sentry Node ESM — https://docs.sentry.io/platforms/javascript/guides/express/install/esm/
13. Grafana Cloud Linux Integration — https://grafana.com/docs/grafana-cloud/observe-and-act/monitor-infrastructure/integrations/integration-reference/integration-linux-node/
